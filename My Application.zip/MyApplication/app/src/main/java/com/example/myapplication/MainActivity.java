package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private boolean isClicked = false;
    private int value1 = 0;
    private int value2;
    TextView textView;
    TextView textView2;
    Button b0;
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    Button b5;
    Button b6;
    Button b7;
    Button b8;
    Button b9;
    Button bdiv;
    Button btim;
    Button bplu;
    Button bmin;
    Button bequa;
    Button bnegpos;
    Button bdot;
    Button bC;
    Button bCE;
    Button bBS;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViewVariables();
        setOnClickListeners();
    }

    protected void initializeViewVariables(){
        textView = (TextView) findViewById(R.id.txtView);
        textView2 = (TextView) findViewById(R.id.txtView2);
        b0 = (Button) findViewById(R.id.btn_0);
        b1 = (Button) findViewById(R.id.btn_1);
        b2 = (Button) findViewById(R.id.btn_2);
        b3 = (Button) findViewById(R.id.btn_3);
        b4 = (Button) findViewById(R.id.btn_4);
        b5 = (Button) findViewById(R.id.btn_5);
        b6 = (Button) findViewById(R.id.btn_6);
        b7 = (Button) findViewById(R.id.btn_7);
        b8 = (Button) findViewById(R.id.btn_8);
        b9 = (Button) findViewById(R.id.btn_9);
        bplu = (Button) findViewById(R.id.btn_plu);
        bmin = (Button) findViewById(R.id.btn_min);
        btim = (Button) findViewById(R.id.btn_tim);
        bdiv = (Button) findViewById(R.id.btn_div);
        bdot = (Button) findViewById(R.id.btn_dot);
        bequa = (Button) findViewById(R.id.btn_equ);
        bC = (Button) findViewById(R.id.btn_C);
        bCE = (Button) findViewById(R.id.btn_CE);
        bBS = (Button) findViewById(R.id.btn_BS);
        bnegpos = (Button) findViewById(R.id.btn_negpos);
    }

    protected void setOnClickListeners(){
        b1.setOnClickListener(this);
        b0.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        bequa.setOnClickListener(this);
        bplu.setOnClickListener(this);
        bmin.setOnClickListener(this);
        btim.setOnClickListener(this);
        bdiv.setOnClickListener(this);
        bdot.setOnClickListener(this);
        bnegpos.setOnClickListener(this);
        bC.setOnClickListener(this);
        bCE.setOnClickListener(this);
        bBS.setOnClickListener(this);
    }
public void onClick(View view){
    switch (view.getId()){
        case R.id.btn_0:
            addNumber(0);
            break;
        case R.id.btn_1:
            addNumber(1);
            break;
        case R.id.btn_2:
            addNumber(2);
            break;
        case R.id.btn_3:
            addNumber(3);
            break;
        case R.id.btn_4:
            addNumber(4);
            break;
        case R.id.btn_5:
            addNumber(5);
            break;
        case R.id.btn_6:
            addNumber(6);
            break;
        case R.id.btn_7:
            addNumber(7);
            break;
        case R.id.btn_8:
            addNumber(8);
            break;
        case R.id.btn_9:
            addNumber(9);
            break;
        case R.id.btn_plu:
            textView.setText(Integer.toString(value1) + "+");
            value2 = Integer.parseInt(textView2.getText().toString());
            value1 = this.value1 + value2;
            textView2.setText(Integer.toString(value1));
            break;
        case R.id.btn_min:
            textView.setText(Integer.toString(value1) + "-");
            value2 = Integer.parseInt(textView2.getText().toString());
            value1 = this.value1 - value2;
            textView2.setText(Integer.toString(value1));
            break;
        case R.id.btn_tim:
            textView.setText(Integer.toString(value1) + "X");
            value2 = Integer.parseInt(textView2.getText().toString());
            value1 = this.value1 * value2;
            textView2.setText(Integer.toString(value1));
            break;
        case R.id.btn_div:
            textView.setText(Integer.toString(value1) + "/");
            value2 = Integer.parseInt(textView2.getText().toString());
            value1 = this.value1 / value2;
            textView2.setText(Integer.toString(value1));
            break;
        case R.id.btn_dot:
            break;
        case R.id.btn_C:
            textView.setText(Integer.toString(value1));
            value2 = 0;
            textView2.setText(Integer.toString(value2));
            break;
        case R.id.btn_CE:
            value1 = 0;
            value2 = 0;
            textView2.setText(Integer.toString(value1));
            textView.setText(Integer.toString(value1));
            break;
        case R.id.btn_BS:
            value1 = this.value1/10;
            textView2.setText(Integer.toString(value1));
            break;
        case R.id.btn_negpos:
            value1 = -this.value1;
            textView2.setText(Integer.toString(value1));
            break;
        case R.id.btn_equ:
                textView2.setText(Integer.toString(value1));
            break;

    }
}
    private void addNumber(int number)
    {
            value1 = value1 * 10 + number;
            textView2.setText(Integer.toString(value1));
    }

}
